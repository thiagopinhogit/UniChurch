require('dotenv').config();
const mongoose = require('mongoose');
const Church = require('./models/Church');
const User = require('./models/User');
const Group = require('./models/Group');
const GroupMember = require('./models/GroupMember');
const InterestTag = require('./models/InterestTag');
const UserInterest = require('./models/UserInterest');
const Event = require('./models/Event');

const slugify = (str) =>
  str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

const shuffleArray = (array) => {
  const cloned = [...array];
  for (let i = cloned.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [cloned[i], cloned[j]] = [cloned[j], cloned[i]];
  }
  return cloned;
};

const churchesData = [
  {
    name: 'Igreja UniChurch São Paulo',
    city: 'São Paulo',
    qr_code_id: 'unichurch-sp-main',
    logo_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300',
    location: { type: 'Point', coordinates: [-46.6333, -23.5505] },
    address: 'Av. Paulista, 1000 - Bela Vista, São Paulo - SP',
    admin_email: 'demo.admin@unichurch.com',
    admin_password: 'demo123',
    admin_name: 'Demo Admin',
    secondary_admin_name: 'Pra. Juliana Mendes',
    secondary_admin_email: 'juliana.sp@unichurch.com'
  },
  {
    name: 'Igreja Comunidade Rio de Janeiro',
    city: 'Rio de Janeiro',
    qr_code_id: 'comunidade-rj-copacabana',
    logo_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300',
    location: { type: 'Point', coordinates: [-43.1729, -22.9068] },
    address: 'Av. Atlântica, 500 - Copacabana, Rio de Janeiro - RJ',
    admin_email: 'admin.rj@unichurch.com',
    admin_password: 'unichurch123',
    admin_name: 'Pra. Daniela Albuquerque',
    secondary_admin_name: 'Pr. Marcos Vieira',
    secondary_admin_email: 'marcos.rj@unichurch.com'
  },
  {
    name: 'Igreja Nova Vida Curitiba',
    city: 'Curitiba',
    qr_code_id: 'nova-vida-curitiba',
    logo_url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=300',
    location: { type: 'Point', coordinates: [-49.2643, -25.4284] },
    address: 'Rua XV de Novembro, 100 - Centro, Curitiba - PR',
    admin_email: 'admin.ctba@unichurch.com',
    admin_password: 'unichurch123',
    admin_name: 'Pr. Henrique Mattos',
    secondary_admin_name: 'Líder Renata Souza',
    secondary_admin_email: 'renata.ctba@unichurch.com'
  },
  {
    name: 'Igreja Renascer Londrina',
    city: 'Londrina',
    qr_code_id: 'renascer-londrina',
    logo_url: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?w=300',
    location: { type: 'Point', coordinates: [-51.1628, -23.3045] },
    address: 'Av. Higienópolis, 200 - Centro, Londrina - PR',
    admin_email: 'admin.ldn@unichurch.com',
    admin_password: 'unichurch123',
    admin_name: 'Pra. Camila Ribeiro',
    secondary_admin_name: 'Pr. Roberto Pires',
    secondary_admin_email: 'roberto.ldn@unichurch.com'
  },
  {
    name: 'Igreja Esperança Maringá',
    city: 'Maringá',
    qr_code_id: 'esperanca-maringa',
    logo_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300',
    location: { type: 'Point', coordinates: [-51.9389, -23.4205] },
    address: 'Av. Brasil, 300 - Centro, Maringá - PR',
    admin_email: 'admin.mga@unichurch.com',
    admin_password: 'unichurch123',
    admin_name: 'Pr. Eduardo Lopes',
    secondary_admin_name: 'Líder Amanda Costa',
    secondary_admin_email: 'amanda.mga@unichurch.com'
  }
];

const memberProfiles = [
  { name: 'Ana Souza', profession: 'Designer UX', instagram: '@ana.souza', whatsappSuffix: '001' },
  { name: 'Lucas Oliveira', profession: 'Engenheiro de Software', instagram: '@lucasoliv', whatsappSuffix: '002' },
  { name: 'Mariana Lima', profession: 'Professora', instagram: '@marilima', whatsappSuffix: '003' },
  { name: 'Pedro Santos', profession: 'Empreendedor', instagram: '@pedros.santos', whatsappSuffix: '004' },
  { name: 'Fernanda Carvalho', profession: 'Fisioterapeuta', instagram: '@fernandac', whatsappSuffix: '005' },
  { name: 'João Mendes', profession: 'Advogado', instagram: '@jmendes', whatsappSuffix: '006' },
  { name: 'Beatriz Rocha', profession: 'Médica', instagram: '@beatrocha', whatsappSuffix: '007' },
  { name: 'Rafael Costa', profession: 'Arquiteto', instagram: '@rafa.costa', whatsappSuffix: '008' },
  { name: 'Carolina Pereira', profession: 'Marketing Digital', instagram: '@carol.p', whatsappSuffix: '009' },
  { name: 'Gustavo Almeida', profession: 'Músico', instagram: '@gustavo.play', whatsappSuffix: '010' },
  { name: 'Isabela Martins', profession: 'Fotógrafa', instagram: '@isa.foto', whatsappSuffix: '011' },
  { name: 'Thiago Rodrigues', profession: 'Personal Trainer', instagram: '@thiago.fit', whatsappSuffix: '012' }
];

const groupTemplates = [
  { 
    name: 'Célula Central', 
    type: 'CELL', 
    description: 'Célula para jovens casais com encontros semanais nas quartas às 20h.', 
    emoji: '🏠',
    whatsapp_link: 'https://chat.whatsapp.com/CELULACENTRALexample',
    is_private: false
  },
  { 
    name: 'Célula Famílias', 
    type: 'CELL', 
    description: 'Célula focada em famílias com filhos pequenos. Reuniões aos sábados pela manhã.', 
    emoji: '🏡',
    whatsapp_link: 'https://chat.whatsapp.com/CELULAFAMILIASexample',
    is_private: false
  },
  { 
    name: 'Célula Jovens', 
    type: 'CELL', 
    description: 'Célula para jovens de 18 a 30 anos. Encontros de discipulado e comunhão.', 
    emoji: '🎯',
    whatsapp_link: 'https://chat.whatsapp.com/CELULAJOVENSexample',
    is_private: false
  },
  { 
    name: 'Ministério de Louvor', 
    type: 'MINISTRY', 
    description: 'Equipe de louvor e adoração. Ensaios aos domingos após o culto.', 
    emoji: '🎵',
    whatsapp_link: 'https://chat.whatsapp.com/MINLOUVORexample',
    is_private: false
  },
  { 
    name: 'Ministério de Intercessão', 
    type: 'MINISTRY', 
    description: 'Grupo de oração e intercessão. Encontros às quartas-feiras de madrugada.', 
    emoji: '🙏',
    whatsapp_link: 'https://chat.whatsapp.com/MININTERCESSAOexample',
    is_private: true
  },
  { 
    name: 'Grupo de Empreendedores', 
    type: 'PROFESSION', 
    description: 'Rede de apoio e networking para empreendedores cristãos. Café da manhã mensal.', 
    emoji: '💼',
    whatsapp_link: 'https://chat.whatsapp.com/EMPREENDEDORESexample',
    is_private: false
  },
  { 
    name: 'Grupo Tech & Fé', 
    type: 'PROFESSION', 
    description: 'Profissionais de tecnologia compartilhando conhecimento e fé.', 
    emoji: '💻',
    whatsapp_link: 'https://chat.whatsapp.com/TECHFEexample',
    is_private: false
  },
  { 
    name: 'Pelada Unida', 
    type: 'SPORT', 
    description: 'Futebol recreativo toda sexta-feira às 19h no campo do bairro.', 
    emoji: '⚽',
    whatsapp_link: 'https://chat.whatsapp.com/PELADAUNIDAexample',
    is_private: false
  },
  { 
    name: 'Vôlei na Praia', 
    type: 'SPORT', 
    description: 'Vôlei de praia aos sábados pela manhã. Todos os níveis são bem-vindos!', 
    emoji: '🏐',
    whatsapp_link: 'https://chat.whatsapp.com/VOLEIPRAIAexample',
    is_private: false
  },
  { 
    name: 'Clube do Cinema & Café', 
    type: 'HOBBY', 
    description: 'Debates sobre filmes e séries com uma boa xícara de café. Encontros quinzenais.', 
    emoji: '🎬',
    whatsapp_link: 'https://chat.whatsapp.com/CINEMACAFEexample',
    is_private: false
  },
  { 
    name: 'Fotografia Criativa', 
    type: 'HOBBY', 
    description: 'Grupo de fotógrafos amadores e profissionais. Saídas fotográficas mensais.', 
    emoji: '📷',
    whatsapp_link: 'https://chat.whatsapp.com/FOTOCRIATIVAexample',
    is_private: false
  },
  { 
    name: 'Livros & Leitura', 
    type: 'HOBBY', 
    description: 'Clube do livro cristão. Um livro por mês e debates enriquecedores.', 
    emoji: '📚',
    whatsapp_link: 'https://chat.whatsapp.com/LIVROSLEITURAexample',
    is_private: false
  }
];

const createInterestTags = async () => {
  // Esportes e Atividades Físicas (expandido)
  const sports = [
    { name: 'Futebol', category: 'ESPORTE', emoji: '⚽' },
    { name: 'Futsal', category: 'ESPORTE', emoji: '🥅' },
    { name: 'Vôlei', category: 'ESPORTE', emoji: '🏐' },
    { name: 'Vôlei de Praia', category: 'ESPORTE', emoji: '🏖️' },
    { name: 'Basquete', category: 'ESPORTE', emoji: '🏀' },
    { name: 'Corrida', category: 'ESPORTE', emoji: '🏃' },
    { name: 'Caminhada', category: 'ESPORTE', emoji: '🚶' },
    { name: 'Academia/Musculação', category: 'ESPORTE', emoji: '💪' },
    { name: 'Crossfit', category: 'ESPORTE', emoji: '🏋️' },
    { name: 'Ciclismo', category: 'ESPORTE', emoji: '🚴' },
    { name: 'Mountain Bike', category: 'ESPORTE', emoji: '🚵' },
    { name: 'Natação', category: 'ESPORTE', emoji: '🏊' },
    { name: 'Tênis', category: 'ESPORTE', emoji: '🎾' },
    { name: 'Tênis de Mesa', category: 'ESPORTE', emoji: '🏓' },
    { name: 'Artes Marciais', category: 'ESPORTE', emoji: '🥋' },
    { name: 'Yoga', category: 'ESPORTE', emoji: '🧘' },
    { name: 'Pilates', category: 'ESPORTE', emoji: '🤸' },
    { name: 'Dança', category: 'ESPORTE', emoji: '💃' },
    { name: 'Skate', category: 'ESPORTE', emoji: '🛹' },
    { name: 'Surf', category: 'ESPORTE', emoji: '🏄' },
    { name: 'Trilhas/Hiking', category: 'ESPORTE', emoji: '🥾' },
    { name: 'Escalada', category: 'ESPORTE', emoji: '🧗' },
    { name: 'Patins', category: 'ESPORTE', emoji: '⛸️' }
  ];

  // Hobbies e Lazer (expandido)
  const hobbies = [
    { name: 'Música', category: 'HOBBY', emoji: '🎵' },
    { name: 'Canto', category: 'HOBBY', emoji: '🎤' },
    { name: 'Tocar Instrumentos', category: 'HOBBY', emoji: '🎸' },
    { name: 'Fotografia', category: 'HOBBY', emoji: '📷' },
    { name: 'Cinema', category: 'HOBBY', emoji: '🎬' },
    { name: 'Séries', category: 'HOBBY', emoji: '📺' },
    { name: 'Leitura', category: 'HOBBY', emoji: '📚' },
    { name: 'Escrita/Literatura', category: 'HOBBY', emoji: '✍️' },
    { name: 'Café & Conversas', category: 'HOBBY', emoji: '☕' },
    { name: 'Gastronomia/Culinária', category: 'HOBBY', emoji: '👨‍🍳' },
    { name: 'Viagens', category: 'HOBBY', emoji: '✈️' },
    { name: 'Arte/Pintura', category: 'HOBBY', emoji: '🎨' },
    { name: 'Artesanato', category: 'HOBBY', emoji: '🧵' },
    { name: 'Jogos de Tabuleiro', category: 'HOBBY', emoji: '🎲' },
    { name: 'Videogames', category: 'HOBBY', emoji: '🎮' },
    { name: 'Teatro', category: 'HOBBY', emoji: '🎭' },
    { name: 'Jardinagem', category: 'HOBBY', emoji: '🌱' },
    { name: 'Decoração', category: 'HOBBY', emoji: '🏡' },
    { name: 'Podcasts', category: 'HOBBY', emoji: '🎙️' },
    { name: 'Astronomia', category: 'HOBBY', emoji: '🔭' },
    { name: 'Animais/Pets', category: 'HOBBY', emoji: '🐕' },
    { name: 'Voluntariado', category: 'HOBBY', emoji: '🤝' },
    { name: 'Moda/Estilo', category: 'HOBBY', emoji: '👗' }
  ];

  // Fase da Vida (expandido com as principais)
  const lifeStages = [
    { name: 'Solteiro', category: 'FASE_VIDA', emoji: '🙋' },
    { name: 'Solteiro com Filhos', category: 'FASE_VIDA', emoji: '👨‍👧' },
    { name: 'Namorando', category: 'FASE_VIDA', emoji: '💕' },
    { name: 'Noivo/Noiva', category: 'FASE_VIDA', emoji: '💍' },
    { name: 'Casado', category: 'FASE_VIDA', emoji: '💑' },
    { name: 'Casado sem Filhos', category: 'FASE_VIDA', emoji: '👫' },
    { name: 'Pais de Primeira Viagem', category: 'FASE_VIDA', emoji: '👶' },
    { name: 'Pais', category: 'FASE_VIDA', emoji: '👨‍👩‍👧' },
    { name: 'Pais de Adolescentes', category: 'FASE_VIDA', emoji: '👨‍👩‍👧‍👦' },
    { name: 'Pais de Adultos', category: 'FASE_VIDA', emoji: '👴👵' },
    { name: 'Viúvo', category: 'FASE_VIDA', emoji: '🕊️' },
    { name: 'Divorciado', category: 'FASE_VIDA', emoji: '💔' },
    { name: 'Estudante', category: 'FASE_VIDA', emoji: '🎓' },
    { name: 'Jovem Profissional', category: 'FASE_VIDA', emoji: '🧑‍💼' },
    { name: 'Aposentado', category: 'FASE_VIDA', emoji: '🏖️' },
    { name: 'Terceira Idade', category: 'FASE_VIDA', emoji: '👴' }
  ];

  // Faixa Etária (faixas específicas de idade)
  const ageRanges = [
    { name: '13-17 anos', category: 'FAIXA_ETARIA', emoji: '👦' },
    { name: '18-24 anos', category: 'FAIXA_ETARIA', emoji: '👨' },
    { name: '25-29 anos', category: 'FAIXA_ETARIA', emoji: '👨‍🦱' },
    { name: '30-34 anos', category: 'FAIXA_ETARIA', emoji: '👨‍💼' },
    { name: '35-39 anos', category: 'FAIXA_ETARIA', emoji: '👨‍🦰' },
    { name: '40-49 anos', category: 'FAIXA_ETARIA', emoji: '🧔' },
    { name: '50-59 anos', category: 'FAIXA_ETARIA', emoji: '👨‍🦳' },
    { name: '60+ anos', category: 'FAIXA_ETARIA', emoji: '👴' }
  ];

  // Áreas de Interesse (significativamente expandido)
  const areas = [
    // Tecnologia e Inovação
    { name: 'Tecnologia', category: 'AREA_INTERESSE', emoji: '💻' },
    { name: 'Programação/Desenvolvimento', category: 'AREA_INTERESSE', emoji: '👨‍💻' },
    { name: 'Inteligência Artificial', category: 'AREA_INTERESSE', emoji: '🤖' },
    { name: 'Marketing Digital', category: 'AREA_INTERESSE', emoji: '📱' },
    { name: 'Design/UX', category: 'AREA_INTERESSE', emoji: '🎨' },
    
    // Negócios e Carreira
    { name: 'Empreendedorismo', category: 'AREA_INTERESSE', emoji: '🚀' },
    { name: 'Liderança', category: 'AREA_INTERESSE', emoji: '👔' },
    { name: 'Finanças Pessoais', category: 'AREA_INTERESSE', emoji: '💰' },
    { name: 'Investimentos', category: 'AREA_INTERESSE', emoji: '📈' },
    { name: 'Networking', category: 'AREA_INTERESSE', emoji: '🤝' },
    { name: 'Vendas', category: 'AREA_INTERESSE', emoji: '💼' },
    { name: 'Gestão de Projetos', category: 'AREA_INTERESSE', emoji: '📊' },
    
    // Educação e Desenvolvimento
    { name: 'Educação', category: 'AREA_INTERESSE', emoji: '📖' },
    { name: 'Desenvolvimento Pessoal', category: 'AREA_INTERESSE', emoji: '🌟' },
    { name: 'Idiomas', category: 'AREA_INTERESSE', emoji: '🗣️' },
    { name: 'Coaching/Mentoria', category: 'AREA_INTERESSE', emoji: '👨‍🏫' },
    
    // Saúde e Bem-estar
    { name: 'Saúde & Bem-estar', category: 'AREA_INTERESSE', emoji: '🩺' },
    { name: 'Nutrição', category: 'AREA_INTERESSE', emoji: '🥗' },
    { name: 'Saúde Mental', category: 'AREA_INTERESSE', emoji: '🧠' },
    { name: 'Meditação/Espiritualidade', category: 'AREA_INTERESSE', emoji: '🙏' },
    
    // Família e Relacionamentos
    { name: 'Casamento', category: 'AREA_INTERESSE', emoji: '💒' },
    { name: 'Maternidade/Paternidade', category: 'AREA_INTERESSE', emoji: '👶' },
    { name: 'Educação de Filhos', category: 'AREA_INTERESSE', emoji: '👨‍👩‍👧' },
    { name: 'Relacionamentos', category: 'AREA_INTERESSE', emoji: '❤️' },
    
    // Ministérios e Serviço
    { name: 'Missões', category: 'AREA_INTERESSE', emoji: '🌍' },
    { name: 'Evangelismo', category: 'AREA_INTERESSE', emoji: '📣' },
    { name: 'Ação Social', category: 'AREA_INTERESSE', emoji: '🤲' },
    { name: 'Ensino/Discipulado', category: 'AREA_INTERESSE', emoji: '📚' },
    { name: 'Louvor e Adoração', category: 'AREA_INTERESSE', emoji: '🎵' },
    { name: 'Oração/Intercessão', category: 'AREA_INTERESSE', emoji: '🙏' },
    { name: 'Crianças/Infantil', category: 'AREA_INTERESSE', emoji: '👶' },
    { name: 'Adolescentes/Jovens', category: 'AREA_INTERESSE', emoji: '👨‍🎓' },
    
    // Outras Áreas
    { name: 'Comunicação', category: 'AREA_INTERESSE', emoji: '📢' },
    { name: 'Criatividade', category: 'AREA_INTERESSE', emoji: '✨' },
    { name: 'Sustentabilidade', category: 'AREA_INTERESSE', emoji: '♻️' },
    { name: 'Política/Sociedade', category: 'AREA_INTERESSE', emoji: '🏛️' },
    { name: 'Ciências', category: 'AREA_INTERESSE', emoji: '🔬' },
    { name: 'História', category: 'AREA_INTERESSE', emoji: '📜' },
    { name: 'Direito/Justiça', category: 'AREA_INTERESSE', emoji: '⚖️' },
    { name: 'Arquitetura/Urbanismo', category: 'AREA_INTERESSE', emoji: '🏗️' },
    { name: 'Psicologia', category: 'AREA_INTERESSE', emoji: '🧠' }
  ];

  const tags = [...sports, ...hobbies, ...lifeStages, ...ageRanges, ...areas];
  await InterestTag.insertMany(tags);
  return tags.length;
};

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    await Promise.all([
      Church.deleteMany({}),
      User.deleteMany({}),
      Group.deleteMany({}),
      GroupMember.deleteMany({}),
      InterestTag.deleteMany({}),
      Event.deleteMany({})
    ]);
    console.log('🗑️  Cleared existing data');

    const interestCount = await createInterestTags();
    console.log(`✅ Inserted ${interestCount} interest tags`);

    const allEvents = [];

    for (const [index, churchData] of churchesData.entries()) {
      const church = new Church(churchData);
      await church.save();

      console.log(`\n➡️  Seeding church: ${church.name}`);

      // Criar admin principal
      const adminUser = await User.create({
        church_id: church._id,
        name: church.admin_name,
        email: church.admin_email,
        phone: `11${index + 1}9000000`,
        show_profile: true,
        show_whatsapp: true,
        show_instagram: false,
        whatsapp: `11${index + 1}9000000`,
        profession: 'Pastor(a)',
        is_new: false,
        is_church_admin: true,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 90)
      });

      // Criar admin secundário
      const secondaryAdminUser = await User.create({
        church_id: church._id,
        name: churchData.secondary_admin_name,
        email: churchData.secondary_admin_email,
        phone: `11${index + 1}9000001`,
        show_profile: true,
        show_whatsapp: true,
        show_instagram: false,
        whatsapp: `11${index + 1}9000001`,
        profession: 'Líder',
        is_new: false,
        is_church_admin: true,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * 85)
      });

      const churchSlug = slugify(church.city || church.name);
      const memberDocs = [];

      for (const [mIndex, profile] of memberProfiles.entries()) {
        const email = `${slugify(profile.name)}.${churchSlug}${mIndex}@unichurch.com`;
        const member = await User.create({
          church_id: church._id,
          name: profile.name,
          email,
          phone: `11${index + 1}9${(80000000 + mIndex * 137 + index * 1000).toString().slice(-8)}`,
          whatsapp: `11${index + 1}9${(80000000 + mIndex * 137 + index * 1000).toString().slice(-8)}`,
          show_whatsapp: mIndex % 2 === 0,
          show_profile: true,
          instagram: profile.instagram,
          show_instagram: Boolean(profile.instagram),
          profession: profile.profession,
          is_new: mIndex >= memberProfiles.length - 2,
          created_at: new Date(Date.now() - (mIndex + 2) * 1000 * 60 * 60 * 24)
        });
        memberDocs.push(member);

        if (mIndex < 3) {
          allEvents.push({
            church_id: church._id,
            user_id: member._id,
            type: 'NEW_MEMBER',
            created_at: new Date(Date.now() - (mIndex + 1) * 1000 * 60 * 60 * 12)
          });
        }
      }

      const membersPool = [adminUser, secondaryAdminUser, ...memberDocs];

      const churchGroupsData = groupTemplates.map((template, gIndex) => ({
        ...template,
        church_id: church._id,
        name: `${template.name} ${church.city.split(' ')[0]}`,
        description: `${template.description} (${church.city})`,
        created_by: adminUser._id,
        created_at: new Date(Date.now() - (gIndex + 1) * 1000 * 60 * 60 * 6),
        is_active: true,
        pending_requests: []
      }));

      const createdGroups = await Group.insertMany(churchGroupsData);
      const membershipDocs = [];

      for (const [groupIndex, group] of createdGroups.entries()) {
        // Definir número de membros por grupo (variando entre 5 e 10)
        const numMembers = 5 + Math.floor(Math.random() * 6);
        const randomMembers = shuffleArray(memberDocs).slice(0, numMembers);
        
        // Todos os grupos têm o admin principal como membro
        const groupMembers = [adminUser, ...randomMembers];
        
        // Definir admins do grupo
        let groupAdmins = [adminUser._id]; // Admin da igreja é sempre admin do grupo
        
        // Para alguns grupos, adicionar o segundo admin da igreja
        if (groupIndex % 2 === 0) {
          groupAdmins.push(secondaryAdminUser._id);
          if (!groupMembers.includes(secondaryAdminUser)) {
            groupMembers.push(secondaryAdminUser);
          }
        }
        
        // Adicionar 1-2 membros regulares como admins do grupo
        const potentialGroupAdmins = randomMembers.slice(0, Math.min(2, randomMembers.length));
        potentialGroupAdmins.forEach(member => {
          if (Math.random() > 0.5) {
            groupAdmins.push(member._id);
          }
        });

        // Atualizar o grupo com os admins
        await Group.findByIdAndUpdate(group._id, {
          admins: groupAdmins
        });

        // Criar membros do grupo
        groupMembers.forEach((member, memberIdx) => {
          membershipDocs.push({
            group_id: group._id,
            user_id: member._id,
            joined_at: new Date(Date.now() - (memberIdx + 1) * 1000 * 60 * 60 * 2)
          });

          if (member._id.toString() !== adminUser._id.toString() && 
              member._id.toString() !== secondaryAdminUser._id.toString()) {
            const eventType =
              group.type === 'CELL' && memberIdx === 1 ? 'FIRST_CELL' : 'JOIN_GROUP';
            allEvents.push({
              church_id: church._id,
              user_id: member._id,
              group_id: group._id,
              type: eventType,
              created_at: new Date(Date.now() - (memberIdx + 2) * 1000 * 60 * 30)
            });
          }
        });

        // Atualizar cell_id para membros de células
        if (group.type === 'CELL') {
          const idsToUpdate = groupMembers.map((member) => member._id);
          await User.updateMany(
            { _id: { $in: idsToUpdate } },
            { cell_id: group._id }
          );
        }
      }

      await GroupMember.insertMany(membershipDocs);

      // ============================================
      // CRIAR USUÁRIOS DEMO PARA TESTE DA APPLE (apenas na primeira igreja)
      // ============================================
      if (index === 0) {
        console.log(`\n📱 Criando usuários DEMO para testes...`);
        
        // Demo Membro
        const demoMember = new User({
          church_id: church._id,
          name: 'Demo Membro',
          email: 'demo.membro@unichurch.com',
          password: 'demo123',
          auth_provider: 'email',
          profession: 'Testador',
          whatsapp: '+5511999998888',
          instagram: '@demomembro',
          show_profile: true,
          show_whatsapp: true,
          show_instagram: true,
          is_new: false
        });
        await demoMember.save();

        // Adicionar alguns interesses ao demo membro
        const demoInterests = [
          'Futebol', 'Música', 'Tecnologia', 'Voluntariado'
        ];
        
        for (const interestName of demoInterests) {
          const tag = await InterestTag.findOne({ name: interestName });
          if (tag) {
            await UserInterest.create({
              user_id: demoMember._id,
              interest_tag_id: tag._id
            });
          }
        }

        // Adicionar demo membro a alguns grupos
        const someGroups = createdGroups.slice(0, 3);
        for (const group of someGroups) {
          await GroupMember.create({
            group_id: group._id,
            user_id: demoMember._id,
            joined_at: new Date()
          });
        }

        console.log(`   ✅ Demo Membro: demo.membro@unichurch.com / demo123`);
        console.log(`   ✅ Demo Admin: demo.admin@unichurch.com / demo123 (Church Admin)`);
        console.log(`   📍 Igreja: ${church.name} (${church.qr_code_id})`);

        console.log(
          `   • ${memberDocs.length + 3} membros (incluindo 1 demo + ${adminUser.name}, ${secondaryAdminUser.name})`
        );
      } else {
        console.log(
          `   • ${memberDocs.length + 2} membros (${adminUser.name}, ${secondaryAdminUser.name} + ${memberDocs.length})`
        );
      }
      console.log(`   • ${createdGroups.length} grupos criados (com admins de grupo definidos)`);
      console.log(`   • Todos os grupos têm links do WhatsApp configurados`);
    }

    if (allEvents.length > 0) {
      await Event.insertMany(allEvents);
      console.log(`\n🗞️  ${allEvents.length} eventos gerados para o mural`);
    }

    console.log('\n🎉 Database seeded successfully!');
    console.log('📋 Summary:');
    console.log(`   Churches: ${churchesData.length}`);
    console.log(`   Church Admins per church: 2 (principal + secundário)`);
    console.log(`   Members per church: ${memberProfiles.length + 2}`);
    console.log(`   Groups per church: ${groupTemplates.length}`);
    console.log(`   Interest Tags: ${interestCount}`);
    console.log('\n📱 WhatsApp Links: Todos os grupos têm links configurados');
    console.log('👥 Group Admins: Cada grupo tem 2-4 admins (incluindo admins da igreja)');

    await mongoose.disconnect();
    console.log('\n✅ Disconnected from MongoDB');
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
